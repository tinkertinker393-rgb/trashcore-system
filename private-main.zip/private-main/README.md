<p align="center">
<img src="https://url.bwmxmd.online/Adams.36pxd22m.jpg" alt="Trashcore Bot" width="500"/>


* private repo for trashcore md


> This base $ bot was created by Trashcore devs





> CURRENT VERSION: 1.8.0
>
> 
> RELEASE ON: 20th July 2025
>
> 
> LAST UPDATED: 26th August 2025
